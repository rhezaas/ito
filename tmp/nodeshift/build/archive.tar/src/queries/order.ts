import { QueryModel } from '../abstracts'

export class OrderQuery extends QueryModel {
    
}